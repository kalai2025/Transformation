package com.jayway.jsonpath.spi.transformer.jsonpathtransformer.model;

import java.util.HashMap;

public class TableData extends HashMap<String, String> {

}
